/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

var dbObj = window.openDatabase("MyDB", "1.0", "Cordova Demo", 200000);

function DBonInt()
{
       //(dbname,ver,db display name,functions);
      dbObj.transaction(populateDB, errorCB, successCB);
      function populateDB(tx) {  
      //table craetion for contact saving
        if(tx.executeSql('CREATE TABLE IF NOT EXISTS CONTACT (id int(11) ,name varchar(90),contact int(15))'))
        console.log("table created");
                }
        function errorCB(tx, err) {
           alert("Error processing SQL: "+err);
       }

       // Transaction success callback
       //
       function successCB() {
           console.log("success!");
           //alert("success!");
       }  
};

function insertContact(id, name, contact){
        dbObj.transaction(populateDB, errorCB, successCB);
        function populateDB(tx) {                    
            if(tx.executeSql('INSERT INTO CONTACT (id,name,contact) VALUES ('+id+','+name+','+contact+')'))
            {
                console.log("data inserted");
            }
            //alert("Successfull");
            }

            // Transaction error callback
           function errorCB(tx, err) {
               alert("Error processing SQL: "+err);
           }

           // Transaction success callback
           function successCB() {
           //    alert("success!");
           }
};
