// Initialize your app
var myApp = new Framework7();

//global variable for msg
var msg;

//global var by setting items locally
localStorage.setItem("applicationName","MyTemplate"); //for app name
localStorage.setItem("url","http://10.42.0.57//iot/application/rest");  //for url
// Export selectors engine
var $$ = Dom7;

// Add view
var mainView = myApp.addView('.view-main', {
    // Because we use fixed-through navbar we can enable dynamic navbar
    dynamicNavbar: true
});

//contact finding code
function findContact()
{
    //not working contact 
  //navigator.co
};

// Callbacks to run specific code for specific pages, for example for About page:
myApp.onPageInit('about', function (page) {
    // run createContentPage func after link was clicked
    $$('.create-page').on('click', function () {
        createContentPage();
    });
});


// Generate dynamic page
var dynamicPageIndex = 0;
function createContentPage() {
	mainView.router.loadContent(
        '<!-- Top Navbar-->' +
        '<div class="navbar">' +
        '  <div class="navbar-inner">' +
        '    <div class="left"><a href="#" class="back link"><i class="icon icon-back"></i><span>Back</span></a></div>' +
        '    <div class="center sliding">Dynamic Page ' + (++dynamicPageIndex) + '</div>' +
        '  </div>' +
        '</div>' +
        '<div class="pages">' +
        '  <!-- Page, data-page contains page name-->' +
        '  <div data-page="dynamic-pages" class="page">' +
        '    <!-- Scrollable page content-->' +
        '    <div class="page-content">' +
        '      <div class="content-block">' +
        '        <div class="content-block-inner">' +
        '          <p>Here is a dynamic page created on ' + new Date() + ' !</p>' +
        '          <p>Go <a href="#" class="back">back</a> or go to <a href="services.html">Services</a>.</p>' +
        '        </div>' +
        '      </div>' +
        '    </div>' +
        '  </div>' +
        '</div>'
    );
	return;
}

$(document).ready(function(){
        $("p").click(function(){
            $(this).hide();
        });
    });
    
myApp.onPageInit('login-screen', function (page) {
  var pageContainer = $$(page.container);
  pageContainer.find('.signin').on('click', function () {
    var username = pageContainer.find('input[name="username"]').val();
    var password = pageContainer.find('input[name="password"]').val();
    
      //storing at local
      //localStorage.setItem(username);
    
    // Handle username and password
    $.ajax({
      type: "POST",
      url: "http://10.42.0.57//iot/application/rest/login.php",
      data: { username: username, password: password }
    }).done(function( msg ) {  
          $.each(jQuery.parseJSON(msg), function(i, field){
           // $("#Jsondata").append("Title: "+ field.success + " duration: "+field.duration +" Price:"+field.price+"<br/>");
            if(field.error === false){
          
              myApp.alert(field.message,"Welcome", function () {
              localStorage.setItem("id",field.id);
              localStorage.setItem("name",field.name);
              //localStorage.setItem("count",field.count);
              
              
              //incert in contact table start    
              $.getJSON("http://10.42.0.57//iot/application/rest/contact.php",function(result)
            {
                $.each(result, function(i, field)
                { 
                      insertContact(field.id,field.name,field.contact);
                      
                });
            });
              //incert in contact table end   

              
                   // code for signin button hide
                    $(document.getElementById("signin")).hide();
                    $(document.getElementById("register")).hide();
                    
              mainView.loadPage("index.html");
              $('.Logout').click(function(){
                    $(this).show();
                    });
              //document.getElementById("profile_name").innerHTML(); //setting name for profile in index.html
              
              });
            }  
            else
            {              
                myApp.alert(field.message,"Try Again", function () {
                username="";
                password="";
                 });
            }
          }); 
        }); 
    });
});


//code for closing app
function exitApp()
             {
                 //window.close(); // work for browser only
                this.window.close();  // work for browser only 
                //navigator.app.exitApp(); //not working
                //myApp.closeModal('index'); //not worked
                mainView.goBack();
             }

//for changing profile name
myApp.onPageInit('index',function (page){
    
        //create db start
        DBonInt();
        //create db end
        document.getElementById("profile_name").innerHTML=localStorage.getItem("name").toString();
        
    
        $(document).ready(function() 
        {
            //code for logout button hide
            if(localStorage.getItem("name")===true)
            {
                $(document.getElementById("Logout")).show();
            }   
            else
            {
                $(document.getElementById("Logout")).hide();            
            }
            $.getJSON("http://10.42.0.57//iot/application/rest/contact.php",function(result)
            {
                $.each(result, function(i, field)
                { 
                    
                    $("#contact").append('<li>'+
                    '<a href='+ field.id +' class="item-link">'+
                    '<div class="item-content">'+
                    '<div class="item-inner">'+
                      '<div class="item-title">'+ field.name+' '+ field.count+'</div>'+
                    '</div>'+
                    '</div>'+
                    '</a>'+
                    '</li>');
                });
            });
        });
    
    var pageContainer = $$ (page.container);
    pageContainer.find('.send').on('click', function () {
    var text = pageContainer.find('input[name="msgText"]').val();

    // Handle username and password
    $.ajax({
      type: "POST",
      url: "http://10.42.0.57//iot/application/rest/chat.php",
      data: { from : from , to : to}
    }).done(function( msg ) {  
          $.each(jQuery.parseJSON(msg), function(i, field){
           // $("#Jsondata").append("Title: "+ field.success + " duration: "+field.duration +" Price:"+field.price+"<br/>");
            if(field.error === false){
              myApp.alert(field.message,"Welcome", function () {              
              //document.getElementById("profile_name").innerHTML(); //setting name for profile in index.html
              });
            }  
            else
            {              
                myApp.alert(field.message,"Try Again", function () {
                    text="";
                 });
            }
          }); 
        });
   //pageContainer.find('.profile_name').valueOf(localStorage.getItem(msg));
});

myApp.onPageInit('register', function (page) {
  var pageContainer = $$(page.container);
  pageContainer.find('.submit').on('click', function () {
    var name = pageContainer.find('input[name="name"]').val();
    var email = pageContainer.find('input[name="email"]').val();
    var password = pageContainer.find('input[name="password"]').val();
    var phone = pageContainer.find('input[name="phone"]').val();
    var gender = pageContainer.find('select[name="gender"]').val();
    var dob = pageContainer.find('input[name="dob"]').val();
    var aboutyou = pageContainer.find('textarea[name="aboutyou"]').val();
    var token=localStorage.getItem('registrationId');
    
    pageContainer.find('.mydiv').valueOf(token.toString());
    // Handle register
    if (name == "") {
        myApp.alert('please enter your name', function () {
            mainView.goBack();
        });
        pageContainer.find('input[name="name"]').focus(); 
    } else if (email == "") {
        myApp.alert('please enter your email', function () {
            mainView.goBack();
        });
        pageContainer.find('input[name="email"]').focus(); 
    } else if (password == "") {
        myApp.alert('please enter your password', function () {
            mainView.goBack();
        });
        pageContainer.find('input[name="email"]').focus(); 
    } else if (phone == "") {
        myApp.alert('please enter your phone', function () {
            mainView.goBack();
        });
        pageContainer.find('input[name="email"]').focus(); 
    } else if (aboutyou == "") {
        myApp.alert('please write About yourself', function () {
            mainView.goBack();
        });
        pageContainer.find('input[name="email"]').focus(); 
    } else if (!isNaN(name)) {
        myApp.alert('please please enter valid name', function () {
            mainView.goBack();
        });
        pageContainer.find('input[name="email"]').focus(); 
    }else if (!email.includes("@") || !email.includes(".")) {
        myApp.alert('please enter valid Email', function () {
            mainView.goBack();
        });
        pageContainer.find('input[name="email"]').focus(); 
    }else if (isNaN(phone) || phone.length != 10) {
        myApp.alert('please enter valid Phone number', function () {
            mainView.goBack();
        });
        pageContainer.find('input[name="email"]').focus(); 
    }else{
//        myApp.alert('Name: ' + name + ', Email: ' + email + ', Pass: ' + password + ', Phone: ' + phone + ', Gender: ' + gender + ', dob: ' + dob + ', about you: ' + aboutyou, function () {
//            mainView.goBack();
//        });
    
    
    //code for saving data
    $.ajax({
      type: "POST",
      url: "http://10.42.0.57//iot/application/rest/register.php",
      data: { name: name , email : email , password : password , phone : phone , gender : gender , dob : dob , aboutyou : aboutyou , token : token }
    }).done(function(msg) {
        $.each(jQuery.parseJSON(msg), function(i, field){
          if(field.error === false){
              myApp.alert(field.message, "Thanks", function () {
              localStorage.setItem("id",field.id);
              
             // mainView.loadPage("login-screen-page.html");
              //document.getElementById("profile_name").innerHTML(); //setting name for profile in index.html
              });
          }  
          else
          {              
              myApp.alert(field.message, "Try Again", function () {
              name="";
              email="";
              password="";
              phone="";
              gender="";
              dob="";
              aboutyou="";
               });
          }
        });
    });
    }
  });
});
});